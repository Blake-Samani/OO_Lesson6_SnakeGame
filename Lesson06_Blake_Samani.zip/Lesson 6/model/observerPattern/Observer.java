package model.observerPattern;

public interface Observer {
    
    void snakeAteFood();;
    void snakeAtePoison();
    void snakeLeftScene();
    void snakeSelfCollision();
}
